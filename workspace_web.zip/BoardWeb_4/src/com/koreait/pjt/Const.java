package com.koreait.pjt;

public class Const {
	public static final String LOGIN_USER = "loginUser";
	
}
